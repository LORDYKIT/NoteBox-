/**
 * @file app.js
 * @description Main application file for setting up and configuring the Express server.
 */

// Load environment variables from a .env file
require("dotenv").config();

const express = require("express");
const expressLayouts = require("express-ejs-layouts");
const methodOverride = require("method-override");
const connectDB = require("./server/config/db");
const session = require("express-session");
const MongoStore = require("connect-mongo");

const app = express();
const port = process.env.PORT || 5000;

// Configure session middleware with MongoStore for session storage
app.use(
  session({
    secret: "keyboard cat",
    resave: false,
    saveUninitialized: true,
   
  })
);

// Parse incoming request bodies as form data
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Enable HTTP method override for PUT and DELETE requests
app.use(methodOverride("_method"));

// Connect to the MongoDB database
connectDB();

// Serve static files from the 'public' directory
app.use(express.static("public"));

// Set up Express to use EJS as the templating engine
app.use(expressLayouts);
app.set("layout", "./layouts/main");
app.set("view engine", "ejs");

// Define routes for different parts of the application
app.use("/test", require("./server/routes/crudstest.js")); // CRUD test routes
app.use("/", require("./server/routes/auth")); // Authentication routes
app.use("/", require("./server/routes/index")); // General application routes
app.use("/", require("./server/routes/dashboard")); // Dashboard routes

// Handle 404 errors by rendering a 404 page
app.get("*", function (req, res) {
  res.status(404).render("404");
});

// Start the Express server
app.listen(port, () => {
  console.log(`App listening on port ${port}`);
});
