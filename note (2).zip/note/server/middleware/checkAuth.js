/**
 * @file checkAuth.js
 * @description Middleware for checking user authentication status.
 */

/**
 * @function isLoggedIn
 * @description Middleware function that checks if a user is authenticated.
 * @param {Object} req - Express request object.
 * @param {Object} res - Express response object.
 * @param {function} next - Express next function.
 * @returns {void} Calls the next function if the user is authenticated, otherwise redirects to the homepage with a 403 status.
 */
exports.isLoggedIn = function (req, res, next) {
   // Check if the user is authenticated based on the presence of a user session
  if (req.session.user) {
   // User is authenticated, proceed to the next middleware function
    next();
  } else {
    // User is not authenticated, redirect to the homepage with a 403 status
    return res.status(403).redirect("/");
  }
};

/**
 * @function redirectToDashboardIfLoggedIn
 * @description Middleware function that redirects a logged-in user to the dashboard.
 * @param {Object} req - Express request object.
 * @param {Object} res - Express response object.
 * @param {function} next - Express next function.
 * @returns {void} Redirects to the dashboard if the user is logged in, otherwise calls the next middleware function.
 */
exports.redirectToDashboardIfLoggedIn = function (req, res, next) {
  // Check if the user is logged in based on the presence of a user session
  if (req.session.user) {
    // User is logged in, redirect to the dashboard
    res.redirect("/dashboard");
  } else {
    next();
  }
};
