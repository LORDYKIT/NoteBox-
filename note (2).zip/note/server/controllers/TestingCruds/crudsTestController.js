/**
 * @file crudsTestController.js
 * @description Controller for testing CRUD operations related to user authentication and note management.
 */

const User = require("../../models/User");
const Note = require("../../models/Notes");
const bcrypt = require("bcrypt");


/**
 * @function loginUser
 * @description Handles user login for testing purposes.
 * @param {Object} req - Express request object.
 * @param {Object} res - Express response object.
 * @returns {void} Responds with a JSON message indicating success or failure of the login attempt.
 */
const loginUser = async (req, res) => {
  const { email, password } = req.body;

  try {
    // Find user by email
    const user = await User.findOne({ email });

    // Validate email and password inputs
    if (!email || !password) {
      return res
        .status(401)
        .json({ message: "email or password inputs missing" });
    }

    // Check if user exists
    if (!user) {
      return res.status(401).json({ message: "User not registered yet" });
    }

    // Validate password
    const isValidPassword = await bcrypt.compare(password, user.password);

    if (!isValidPassword) {
      return res.status(401).json({ error: "Invalid email or password" });
    }

    // Set user session and respond with user information
    req.session.user = user;
    return res.status(200).json(req.session.user);
  } catch (error) {
    console.error(error);
    res.status(500).send("Internal Server Error");
  }
};


/**
 * @function registerUser
 * @description Handles user registration for testing purposes.
 * @param {Object} req - Express request object.
 * @param {Object} res - Express response object.
 * @returns {void} Responds with a JSON message indicating success or failure of the registration attempt.
 */
const registerUser = async (req, res) => {
  const { firstName, lastName, email, password } = req.body;

  try {
    // Validate input fields
    if (!firstName || !lastName || !email || !password) {
      return res.status(401).json({ error: "missing input fields" });
    }

    // Check password length
    if (password.length < 8) {
      return res.status(401).json({
        error: "Password must be longer than 8 digits",
      });
    }
    // Check if user already exists
    const existingUser = await User.findOne({ email });

    if (existingUser) {
      return res.status(401).json({ error: "User already exists" });
    }

    // Hash password and create a new user
    const hashedPassword = await bcrypt.hash(password, 10);

    const newUser = new User({
      firstName,
      lastName,
      email,
      password: hashedPassword,
    });
    await newUser.save();

    // Set user session and respond with new user information
    req.session.user = newUser;
    res
      .status(200)
      .json({ message: "New user Added", Newuser: req.session.user });
  } catch (error) {
    console.error(error);
    res.status(500).send("Internal Server Error");
  }
};


/**
 * @function dashboard
 * @description Retrieves all notes associated with the currently authenticated user for testing purposes.
 * @param {Object} req - Express request object.
 * @param {Object} res - Express response object.
 * @returns {void} Responds with a JSON array of notes.
 */
const dashboard = async (req, res) => {
  try {
    // Retrieve all notes associated with the user
    const notes = await Note.find({ user: req.session.user._id });

    // Respond with the array of notes
    res.status(200).json(notes);
  } catch (error) {
    console.log(error);
  }
};


/**
 * @function dashboardViewNote
 * @description Retrieves details of a specific note for viewing during testing.
 * @param {Object} req - Express request object.
 * @param {Object} res - Express response object.
 * @returns {void} Responds with a JSON object containing details of the requested note.
 */
const dashboardViewNote = async (req, res) => {
  try {
    // Retrieve details of the requested note
    const note = await Note.findById(req.params.id)
      .where({ user: req.session.user._id })
      .lean();

    // Respond with the note details if found, otherwise, respond with an error message
    if (note) {
      res.status(200).json({
        noteID: req.params.id,
        note,
      });
    } else {
      res.status(401).send({ message: "Note id not found" });
    }
  } catch (error) {
    res.status(500).send("Something went Wrong");
  }
};


/**
 * @function dashboardUpdateNote
 * @description Updates the content of a specific note during testing.
 * @param {Object} req - Express request object.
 * @param {Object} res - Express response object.
 * @returns {void} Responds with a JSON message indicating success or failure of the update attempt.
 */
const dashboardUpdateNote = async (req, res) => {
  try {
    // Validate input fields
    if (!req.body.title || !req.body.body)
      return res.status(401).json({
        message: `Title or body input missing`,
      });

      // Check if the note exists
      const existingNote = await Note.findOne({ _id: req.params.id, user: req.session.user._id });

    if (!existingNote) {
      return res.status(404).json({
        message: "Note not found",
      });
    }

    // Update the note and respond with a success message
    await Note.findOneAndUpdate(
      { _id: req.params.id },
      { title: req.body.title, body: req.body.body, updatedAt: Date.now() }
    ).where({ user: req.session.user._id });
    res.status(200).json({ message: "Note Updated Successfully" });
  } catch (error) {
    res.status(500).send("Something went Wrong");
  }
};


/**
 * @function dashboardDeleteNote
 * @description Deletes a specific note during testing.
 * @param {Object} req - Express request object.
 * @param {Object} res - Express response object.
 * @returns {void} Responds with a JSON message indicating success or failure of the deletion attempt.
 */
const dashboardDeleteNote = async (req, res) => {
  try {
    // Find the note by ID
    const note = await Note.findById({ _id: req.params.id });
   
    if (!note)
      return res.status(401).json({
        message: `Note Not found`,
      });

    // Delete the note and respond with a success message
    const notes = await Note.deleteOne({ _id: req.params.id }).where({
      user: req.session.user._id,
    });
    
    console.log("_id: req.params.id", notes);
    res
      .status(200)
      .json({ message: `Note with id ${req.params.id} Deleted Successfully` });
  } catch (error) {
    res.status(500).send("Something went Wrong");
  }
};


/**
 * @function dashboardAddNoteSubmit
 * @description Adds a new note to the user's dashboard during testing.
 * @param {Object} req - Express request object.
 * @param {Object} res - Express response object.
 * @returns {void} Responds with a JSON message indicating success or failure of the addition attempt.
 */
const dashboardAddNoteSubmit = async (req, res) => {
  try {
    // Set the user field in the request body
    req.body.user = req.session.user._id;

    // Create a new note and respond with a success message
    const newNote = await Note.create(req.body);
    res.status(200).json({ message: "New Note Added", newNote });
  } catch (error) {
    res.status(500).send("Something went Wrong");
  }
};


/**
 * @function dashboardSearchSubmit
 * @description Searches for notes based on a provided search term during testing.
 * @param {Object} req - Express request object.
 * @param {Object} res - Express response object.
 * @returns {void} Responds with a JSON array of search results or an error message.
 */
const dashboardSearchSubmit = async (req, res) => {
  try {
    // Get the search term from the request body
    let searchTerm = req.body.searchTerm;

    // Remove special characters from the search term
    const searchNoSpecialChars = searchTerm.replace(/[^a-zA-Z0-9 ]/g, "");

    // Search for notes using regular expressions and respond with the results
    const searchResults = await Note.find({
      $or: [
        { title: { $regex: new RegExp(searchNoSpecialChars, "i") } },
        { body: { $regex: new RegExp(searchNoSpecialChars, "i") } },
      ],
    }).where({ user: req.session.user._id });

    res.status(200).json(searchResults);
  } catch (error) {
    res.status(500).send("Something went Wrong");
  }
};

const getNotebyTitle = async (req, res) => {
  try {
    // Find the note by ID
    Note.deleteOne({ title: req.params.title });

    if (!note)
      return res.status(401).json({
        message: `Note Not found`,
      });

    // Delete the note and respond with a success message
    const notes = await Note.deleteOne({ title: req.params.title });
    
    console.log("_id: req.params.title", notes);
    res
      .status(200)
      .json({ message: `Note with title ${req.params.title} Deleted Successfully` });
  } catch (error) {
    res.status(500).send("Something went Wrong");
  }
};

/**
 * @module.exports
 * @description Exports all the defined functions for use in other parts of the application.
 */
module.exports = {
  loginUser,
  registerUser,
  dashboardSearchSubmit,
  dashboardDeleteNote,
  dashboardAddNoteSubmit,
  dashboardUpdateNote,
  dashboardViewNote,
  dashboard,
  getNotebyTitle,
};
