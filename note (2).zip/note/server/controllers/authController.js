/**
 * @file authController.js
 * @description Controller handling user authentication operations.
 */

const User = require("../models/User");
const bcrypt = require("bcrypt");

/**
 * @function loginUser
 * @async
 * @description Authenticates a user based on provided email and password.
 * @param {Object} req - Express request object.
 * @param {Object} res - Express response object.
 * @returns {void} Redirects to the dashboard upon successful login.
 */
const loginUser = async (req, res) => {
  const { email, password } = req.body;

  try {
    // Find a user with the provided email
    const user = await User.findOne({ email });

    if (!user) {
      // If user is not found, render the login page with an error message
      return res.render("login", { error: "User not registered yet" });
    }

    // Compare the provided password with the hashed password in the database
    const isValidPassword = await bcrypt.compare(password, user.password);

    if (!isValidPassword) {
      // If the password is not valid, render the login page with an error message
      return res.render("login", { error: "Invalid email or password" });
    }

    // Store user information in the session and redirect to the dashboard
    req.session.user = user;
    res.redirect("/dashboard");
  } catch (error) {
    // Log any errors that occur during the authentication process
    console.error(error);
    res.status(500).send("Internal Server Error");
  }
};

/**
 * @function registerUser
 * @async
 * @description Registers a new user with the provided information.
 * @param {Object} req - Express request object.
 * @param {Object} res - Express response object.
 * @returns {void} Redirects to the dashboard upon successful registration.
 */
const registerUser = async (req, res) => {
  const { firstName, lastName, email, password } = req.body;

  try {
    // Check if the password meets the minimum length requirement
    if (password.length < 8) {
      return res.render("register", {
        error: "Password must be longer than 8 digits",
      });
    }

    // Check if a user with the provided email already exists
    const existingUser = await User.findOne({ email });

    if (existingUser) {
      // If user already exists, render the registration page with an error message
      return res.render("register", { error: "User already exists" });
    }

    // Hash the provided password before saving it to the database
    const hashedPassword = await bcrypt.hash(password, 10);

    // Create a new User instance and save it to the database
    const newUser = new User({
      firstName,
      lastName,
      email,
      password: hashedPassword,
    });
    await newUser.save();

    // Store user information in the session and redirect to the dashboard
    req.session.user = newUser;
    res.redirect("/dashboard");
  } catch (error) {
    // Log any errors that occur during the registration process
    console.error(error);
    res.status(500).send("Internal Server Error");
  }
};

// Export loginUser and registerUser functions for use in the application
module.exports = {
  loginUser,
  registerUser,
};
