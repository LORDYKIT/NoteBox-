/**
 * @file mainController.js
 * @description Controller handling main routes and rendering for the NodeJs Notes application.
 */


/**
 * @function homepage
 * @description Renders the homepage.
 * @param {Object} req - Express request object.
 * @param {Object} res - Express response object.
 * @returns {void} Renders the homepage with the specified layout.
 */
exports.homepage = async (req, res) => {
  // Local variables for rendering
  const locals = {
    title: "NodeJs Notes",
    description: "NodeJS Notes App.",
  };

  // Render the homepage with the specified layout
  res.render("index", {
    locals,
    layout: "../views/layouts/front-page",
  });
};


/**
 * @function about
 * @description Renders the about page.
 * @param {Object} req - Express request object.
 * @param {Object} res - Express response object.
 * @returns {void} Renders the about page with the specified locals.
 */
exports.about = async (req, res) => {
  // Local variables for rendering
  const locals = {
    title: "About - NodeJs Notes",
    description: "NodeJS Notes App.",
  };
  // Render the about page with the specified locals
  res.render("about", locals);
};


/**
 * @function login
 * @description Renders the login page.
 * @param {Object} req - Express request object.
 * @param {Object} res - Express response object.
 * @returns {void} Renders the login page with a null error message.
 */
exports.login = async (req, res) => {
  res.render("login", { error: null });
};


/**
 * @function register
 * @description Renders the register page.
 * @param {Object} req - Express request object.
 * @param {Object} res - Express response object.
 * @returns {void} Renders the register page with a null error message.
 */
exports.register = async (req, res) => {
  res.render("register", { error: null });
};
