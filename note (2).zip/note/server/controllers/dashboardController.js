/**
 * @file dashboardController.js
 * @description Controller handling operations related to the user dashboard.
 */

const Note = require("../models/Notes");
const mongoose = require("mongoose");


/**
 * @function dashboard
 * @async
 * @description Renders the user dashboard, displaying notes sorted by the last update.
 * @param {Object} req - Express request object.
 * @param {Object} res - Express response object.
 * @returns {void} Renders the dashboard page.
 * @throws {Error} If there is an issue retrieving or rendering notes.
 */
exports.dashboard = async (req, res) => {

  // Pagination parameters
  let perPage = 12;
  let page = req.query.page || 1;

  // Local variables for rendering
  const locals = {
    title: "Dashboard",
    description: "NodeJS Notes App.",
  };

  try {
    // Aggregate notes, sort, and apply pagination
    const notes = await Note.aggregate([
      { $sort: { updatedAt: -1 } },
      { $match: { user: mongoose.Types.ObjectId(req.session.user.id) } },
      {
        $project: {
          title: { $substr: ["$title", 0, 30] },
          body: { $substr: ["$body", 0, 100] },
        },
      },
    ])
      .skip(perPage * page - perPage)
      .limit(perPage)
      .exec();

    // Count total notes
    const count = await Note.count();

    // Check if JSON response requested
    if (req.headers["accept"] === "application/json") {
      res.json({ notes });
    } else {
      // Render the dashboard page with notes
      res.render("dashboard/index", {
        userName: req.session.user.firstName,
        locals,
        notes,
        layout: "../views/layouts/dashboard",
        current: page,
        pages: Math.ceil(count / perPage),
      });
    }
  } catch (error) {
    // Handle errors
    res.status(500).send("Something went Wrong");
  }
};


/**
 * @function dashboardViewNote
 * @async
 * @description Renders the view note page for a specific note.
 * @param {Object} req - Express request object.
 * @param {Object} res - Express response object.
 * @returns {void} Renders the view note page with details of the selected note.
 * @throws {Error} If there is an issue retrieving or rendering the note.
 */
exports.dashboardViewNote = async (req, res) => {

  // Find the requested note by ID
  const note = await Note.findById({ _id: req.params.id })
    .where({ user: req.session.user._id })
    .lean();

  // Render the view note page with note details
  if (note) {
    res.render("dashboard/view-note", {
      noteID: req.params.id,
      note,
      layout: "../views/layouts/dashboard",
    });
  } else {
    // Handle note not found
    res.status(500).send("Something went Wrong");
  }
};


/**
 * @function dashboardUpdateNote
 * @async
 * @description Updates the content of a specific note.
 * @param {Object} req - Express request object.
 * @param {Object} res - Express response object.
 * @returns {void} Redirects to the dashboard after updating the note.
 * @throws {Error} If there is an issue updating the note.
 */
exports.dashboardUpdateNote = async (req, res) => {
  try {
    // Update the note based on the provided data
    await Note.findOneAndUpdate(
      { _id: req.params.id },
      { title: req.body.title, body: req.body.body, updatedAt: Date.now() }
    ).where({ user: req.session.user._id });

    // Redirect to the dashboard after updating the note
    res.redirect("/dashboard");
  } catch (error) {
    // Handle errors
    res.status(500).send("Something went Wrong");
  }
};


/**
 * @function dashboardDeleteNote
 * @async
 * @description Deletes a specific note.
 * @param {Object} req - Express request object.
 * @param {Object} res - Express response object.
 * @returns {void} Redirects to the dashboard after deleting the note.
 * @throws {Error} If there is an issue deleting the note.
 */
exports.dashboardDeleteNote = async (req, res) => {
  try {
    // Delete the note based on the provided ID
    await Note.deleteOne({ _id: req.params.id }).where({
      user: req.session.user._id,
    });

    // Redirect to the dashboard after deleting the note
    res.redirect("/dashboard");
  } catch (error) {
    // Handle errors
    res.status(500).send("Something went Wrong");
  }
};


/**
 * @function dashboardAddNote
 * @description Renders the add note page.
 * @param {Object} req - Express request object.
 * @param {Object} res - Express response object.
 * @returns {void} Renders the add note page.
 */
exports.dashboardAddNote = async (req, res) => {
   // Render the add note page
  res.render("dashboard/add", {
    layout: "../views/layouts/dashboard",
  });
};


/**
 * @function dashboardAddNoteSubmit
 * @async
 * @description Handles the submission of a new note.
 * @param {Object} req - Express request object.
 * @param {Object} res - Express response object.
 * @returns {void} Redirects to the dashboard after adding a new note.
 * @throws {Error} If there is an issue creating and saving the new note.
 */
exports.dashboardAddNoteSubmit = async (req, res) => {
  try {
    // Set the user ID for the new note
    req.body.user = req.session.user._id;
    
    // Create and save the new note
    await Note.create(req.body);

    // Redirect to the dashboard after adding the new note
    res.redirect("/dashboard");
  } catch (error) {
    // Handle errors
    res.status(500).send("Something went Wrong");
  }
};


/**
 * @function dashboardSearch
 * @description Renders the search page.
 * @param {Object} req - Express request object.
 * @param {Object} res - Express response object.
 * @returns {void} Renders the search page.
 */
exports.dashboardSearch = async (req, res) => {
  try {
    res.render("dashboard/search", {
      searchResults: "",
      layout: "../views/layouts/dashboard",
    });
  } catch (error) {
    // Handle errors
    res.status(500).send("Something went Wrong");
  }
};


/**
 * @function dashboardSearchSubmit
 * @async
 * @description Handles the submission of a search query.
 * @param {Object} req - Express request object.
 * @param {Object} res - Express response object.
 * @returns {void} Renders the search results page.
 * @throws {Error} If there is an issue retrieving or rendering search results.
 */
exports.dashboardSearchSubmit = async (req, res) => {
  try {
    // Extract the search term from the request
    let searchTerm = req.body.searchTerm;

    // Remove special characters from the search term
    const searchNoSpecialChars = searchTerm.replace(/[^a-zA-Z0-9 ]/g, "");

    // Search for notes based on the modified search term
    const searchResults = await Note.find({
      $or: [
        { title: { $regex: new RegExp(searchNoSpecialChars, "i") } },
        { body: { $regex: new RegExp(searchNoSpecialChars, "i") } },
      ],
    }).where({ user: req.session.user._id });

    // Render the search results page
    res.render("dashboard/search", {
      searchResults,
      layout: "../views/layouts/dashboard",
    });
  } catch (error) {
    // Handle errors
    res.status(500).send("Something went Wrong");
  }
};

/**
 * @function dashboardViewNotes
 * @description Renders the view notes page.
 * @param {Object} req - Express request object.
 * @param {Object} res - Express response object.
 * @returns {void} Renders the view notes page.
 * @throws {Error} If there is an issue retrieving or rendering user notes.
 */
exports.dashboardViewNotes = async (req, res) => {
  try {
    // Retrieve user-specific notes
    const userNotes = await Note.find({ user: req.session.user._id });

    // Render the view notes page
    res.render("dashboard/viewNotes", {
      layout: "../views/layouts/dashboard",
      userNotes,
    });
  } catch (error) {
    // Handle errors
    console.log(error);
  }
};

