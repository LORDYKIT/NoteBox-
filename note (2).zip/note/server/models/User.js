/**
 * @file User.js
 * @description MongoDB model for storing user information in a Node.js application.
 */

const mongoose = require("mongoose");

const Schema = mongoose.Schema;

/**
 * @typedef {Object} User
 * @property {string} firstName - The first name of the user.
 * @property {string} lastName - The last name of the user.
 * @property {string} email - The email address of the user (unique and validated against a regex pattern).
 * @property {string} password - The hashed password of the user.
 * @property {Date} createdAt - The date and time when the user account was created (default: current date and time).
 */

/**
 * @type {Schema}
 * @description Defines the schema for the "User" model.
 */
const UserSchema = new Schema({
  firstName: {
    type: String,
    required: true,
  },
  lastName: {
    type: String,
    required: true,
  },
  email: {
    type: String,
    required: true,
    unique: true,
    match: [
      /^[\w-]+(\.[\w-]+)*@([\w-]+\.)+[a-zA-Z]{2,7}$/,
      "Please enter a valid email address",
    ],
  },
  password: {
    type: String,
    required: true,
    minlength: 8,
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
});

/**
 * @module.exports
 * @description Exports the mongoose model for the "User" schema.
 */
module.exports = mongoose.model("User", UserSchema);
