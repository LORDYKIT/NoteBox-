/**
 * @file Notes.js
 * @description MongoDB model for storing notes.
 */
const mongoose = require("mongoose");

const Schema = mongoose.Schema;

/**
 * @typedef {Object} Note
 * @property {string} title - The title of the note.
 * @property {string} body - The content or body of the note.
 * @property {string} user - The ID of the user associated with the note.
 * @property {Date} createdAt - The date and time when the note was created (default: current date and time).
 * @property {Date} updatedAt - The date and time when the note was last updated (default: current date and time).
 */

/**
 * @type {Schema}
 * @description Defines the schema for the "Note" model.
 */
const NoteSchema = new Schema({
  title: {
    type: String,
    required: true,
  },
  body: {
    type: String,
    required: true,
  },
  user: {
    type: String,
    required: true,
  },
  createdAt: {
    type: Date,
    default: Date.now(),
  },
  updatedAt: {
    type: Date,
    default: Date.now(),
  },
});

/**
 * @module.exports
 * @description Exports the mongoose model for the "Note" schema.
 */
module.exports = mongoose.model("Note", NoteSchema);
