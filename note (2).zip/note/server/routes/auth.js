/**
 * @file auth.js
 * @description Express router for handling authentication routes.
 */

const express = require("express");
const router = express.Router();
const authController = require("../controllers/authController");

/**
 * @route POST /login
 * @description Handles user login requests.
 */
router.post("/login", authController.loginUser);

/**
 * @route POST /register
 * @description Handles user registration requests.
 */
router.post("/register", authController.registerUser);

/**
 * @route GET /logout
 * @description Handles user logout requests.
 * @callback (req, res) => void
 */
router.get("/logout", (req, res) => {
  // Destroy the user session
  req.session.destroy((error) => {
    if (error) {
      // If an error occurs during session destruction, send an error message
      res.send("Error logging out");
    } else {
      // If session is successfully destroyed, redirect to the homepage
      res.redirect("/");
    }
  });
});

/**
 * @module.exports
 * @description Exports the router for use in the application.
 */
module.exports = router;
