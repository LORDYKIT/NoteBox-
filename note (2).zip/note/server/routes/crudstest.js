/**
 * @file crudTest.js
 * @description Express router for handling CRUD operations in a testing environment.
 */

const express = require("express");
const router = express.Router();
const crudsTestController = require("../controllers/TestingCruds/crudsTestController");
const { isLoggedIn } = require("../middleware/checkAuth");

/**
 * @route POST /login
 * @description Handles user login requests.
 * @middleware None
 */
router.post("/login", crudsTestController.loginUser);

/**
 * @route POST /register
 * @description Handles user registration requests.
 * @middleware None
 */
router.post("/register", crudsTestController.registerUser);

/**
 * @route GET /logout
 * @description Handles user logout requests.
 * @middleware None
 */
router.get("/logout", (req, res) => {
  // Destroy the user session
  req.session.destroy((error) => {
    if (error) {
      // If an error occurs during session destruction, send an error message
      res.send("Error logging out");
    } else {
      // If session is successfully destroyed, redirect to the homepage
      res.redirect("/");
    }
  });
});

/**
 * @route POST /dashboard/search
 * @description Handles the submission of a search query in the user dashboard.
 * @middleware isLoggedIn - Checks if the user is authenticated.
 */
router.post(
  "/dashboard/search",
  isLoggedIn,
  crudsTestController.dashboardSearchSubmit
);

/**
 * @route POST /dashboard/add
 * @description Handles the submission of a new note in the user dashboard.
 * @middleware isLoggedIn - Checks if the user is authenticated.
 */
router.post(
  "/dashboard/add",
  isLoggedIn,
  crudsTestController.dashboardAddNoteSubmit
);

/**
 * @route DELETE /dashboard/item-delete/:id
 * @description Handles the deletion of a specific note from the user dashboard.
 * @middleware isLoggedIn - Checks if the user is authenticated.
 */
router.delete(
  "/dashboard/item-delete/:id",
  isLoggedIn,
  crudsTestController.dashboardDeleteNote
);

/**
 * @route PUT /dashboard/item/:id
 * @description Handles the update of a specific note in the user dashboard.
 * @middleware isLoggedIn - Checks if the user is authenticated.
 */
router.put(
  "/dashboard/item/:id",
  isLoggedIn,
  crudsTestController.dashboardUpdateNote
);

/**
 * @route GET /dashboard/item/:id
 * @description Handles the rendering of a specific note in the user dashboard.
 * @middleware isLoggedIn - Checks if the user is authenticated.
 */
router.get(
  "/dashboard/item/:id",
  isLoggedIn,
  crudsTestController.dashboardViewNote
);

/**
 * @route GET /dashboard
 * @description Handles the rendering of the user dashboard.
 * @middleware isLoggedIn - Checks if the user is authenticated.
 */
router.get("/dashboard", isLoggedIn, crudsTestController.dashboard);

/**
 * @module.exports
 * @description Exports the router for use in the application.
 */

router.delete(
  "/dashboard/item-delete/:title",

  isLoggedIn,
  crudsTestController.getNotebyTitle
);

module.exports = router;
