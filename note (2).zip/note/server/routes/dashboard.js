/**
 * @file dashboard.js
 * @description Express router for handling routes related to the user dashboard.
 */

const express = require("express");
const router = express.Router();
const { isLoggedIn } = require("../middleware/checkAuth");
const dashboardController = require("../controllers/dashboardController");

/**
 * @route GET /dashboard
 * @description Renders the user dashboard.
 * @middleware isLoggedIn - Checks if the user is authenticated.
 */
router.get("/dashboard", isLoggedIn, dashboardController.dashboard);

/**
 * @route GET /dashboard/item/:id
 * @description Renders the view for a specific note in the user dashboard.
 * @middleware isLoggedIn - Checks if the user is authenticated.
 */
router.get(
  "/dashboard/item/:id",
  isLoggedIn,
  dashboardController.dashboardViewNote
);

/**
 * @route PUT /dashboard/item/:id
 * @description Updates a specific note in the user dashboard.
 * @middleware isLoggedIn - Checks if the user is authenticated.
 */
router.put(
  "/dashboard/item/:id",
  isLoggedIn,
  dashboardController.dashboardUpdateNote
);

/**
 * @route DELETE /dashboard/item-delete/:id
 * @description Deletes a specific note from the user dashboard.
 * @middleware isLoggedIn - Checks if the user is authenticated.
 */
router.delete(
  "/dashboard/item-delete/:id",
  isLoggedIn,
  dashboardController.dashboardDeleteNote
);

/**
 * @route GET /dashboard/add
 * @description Renders the page for adding a new note in the user dashboard.
 * @middleware isLoggedIn - Checks if the user is authenticated.
 */
router.get("/dashboard/add", isLoggedIn, dashboardController.dashboardAddNote);

/**
 * @route POST /dashboard/add
 * @description Handles the submission of a new note in the user dashboard.
 * @middleware isLoggedIn - Checks if the user is authenticated.
 */
router.post(
  "/dashboard/add",
  isLoggedIn,
  dashboardController.dashboardAddNoteSubmit
);

/**
 * @route GET /dashboard/search
 * @description Renders the search page in the user dashboard.
 * @middleware isLoggedIn - Checks if the user is authenticated.
 */
router.get(
  "/dashboard/search",
  isLoggedIn,
  dashboardController.dashboardSearch
);

/**
 * @route POST /dashboard/search
 * @description Handles the submission of a search query in the user dashboard.
 * @middleware isLoggedIn - Checks if the user is authenticated.
 */
router.post(
  "/dashboard/search",
  isLoggedIn,
  dashboardController.dashboardSearchSubmit
);

/**
 * @route GET /dashboard/viewNotes
 * @description Renders the page displaying all user notes in the user dashboard.
 * @middleware isLoggedIn - Checks if the user is authenticated.
 */
router.get(
  "/dashboard/viewNotes",
  isLoggedIn,
  dashboardController.dashboardViewNotes
);



/**
 * @module.exports
 * @description Exports the router for use in the application.
 */
module.exports = router;
