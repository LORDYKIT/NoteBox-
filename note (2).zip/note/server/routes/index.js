/**
 * @file index.js
 * @description Express router for handling general application routes.
 */

const express = require("express");
const router = express.Router();
const mainController = require("../controllers/mainController");
const { redirectToDashboardIfLoggedIn } = require("../middleware/checkAuth");

/**
 * @route GET /
 * @description Renders the homepage.
 * @middleware redirectToDashboardIfLoggedIn - Redirects logged-in users to the dashboard.
 */
router.get("/", redirectToDashboardIfLoggedIn, mainController.homepage);

/**
 * @route GET /about
 * @description Renders the about page.
 */
router.get("/about", mainController.about);

/**
 * @route GET /login
 * @description Renders the login page.
 */
router.get("/login", mainController.login);

/**
 * @route GET /register
 * @description Renders the registration page.
 */
router.get("/register", mainController.register);

/**
 * @module.exports
 * @description Exports the router for use in the application.
 */
module.exports = router;
